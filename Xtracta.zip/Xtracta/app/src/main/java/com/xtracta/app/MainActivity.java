package com.xtracta.app;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.pm.PackageInstaller;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.*;
import android.provider.Settings;
import android.text.InputType;
import android.text.TextUtils;
import android.text.format.DateFormat;
import android.text.format.Formatter;
import android.view.*;
import android.widget.*;

import java.io.File;
import java.io.IOException;
import java.util.*;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity {
    private static final int NAVY = 0xFF14213D, ORANGE = 0xFFE8590C, SELECTED = 0xFFFFE8D9;

    private static final class Item {
        File file; boolean dir; String name, info;
    }

    private interface Job { void run(Ops.Progress p) throws Exception; }

    private final ExecutorService worker = Executors.newSingleThreadExecutor();
    private final ExecutorService lister = Executors.newSingleThreadExecutor();
    private final Handler ui = new Handler(Looper.getMainLooper());
    private final List<Item> items = new ArrayList<>();
    private final LinkedHashSet<File> selected = new LinkedHashSet<>();
    private final List<File> clipboard = new ArrayList<>();
    private boolean moving, showHidden, busy;
    private int sort, listing;
    private File root, current;
    private TextView title, path, empty;
    private LinearLayout bottom;
    private ListView list;
    private BaseAdapter adapter;

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        root = Environment.getExternalStorageDirectory();
        current = root;
        if (state != null && state.getString("dir") != null) current = new File(state.getString("dir"));
        buildUi();
        if (!hasAccess()) askAccess();
        handleInstall(getIntent());
    }

    @Override protected void onSaveInstanceState(Bundle b) {
        super.onSaveInstanceState(b);
        b.putString("dir", current.getAbsolutePath());
    }

    @Override protected void onResume() { super.onResume(); refresh(); }

    @Override protected void onDestroy() { worker.shutdown(); lister.shutdown(); super.onDestroy(); }

    @Override public void onBackPressed() {
        if (!selected.isEmpty()) { selected.clear(); redraw(); }
        else if (!current.equals(root) && current.getParentFile() != null) go(current.getParentFile());
        else super.onBackPressed();
    }

    /* ---------- permissions ---------- */

    private boolean hasAccess() {
        if (Build.VERSION.SDK_INT >= 30) return Environment.isExternalStorageManager();
        return checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED;
    }

    private void askAccess() {
        if (Build.VERSION.SDK_INT < 30) {
            requestPermissions(new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, 1);
            return;
        }
        new AlertDialog.Builder(this).setTitle("Allow file access")
                .setMessage("Xtracta needs \"All files access\" to browse, compress and extract your files.")
                .setPositiveButton("Open settings", (d, w) -> {
                    try {
                        startActivity(new Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION,
                                Uri.parse("package:" + getPackageName())));
                    } catch (Exception e) {
                        startActivity(new Intent(Settings.ACTION_MANAGE_ALL_FILES_ACCESS_PERMISSION));
                    }
                }).setNegativeButton("Not now", null).show();
    }

    @Override public void onRequestPermissionsResult(int c, String[] p, int[] r) { refresh(); }

    /* ---------- UI ---------- */

    private int dp(int v) { return Math.round(v * getResources().getDisplayMetrics().density); }

    private TextView text(float sp, int color) {
        TextView t = new TextView(this);
        t.setTextSize(sp);
        t.setTextColor(color);
        return t;
    }

    private Button button(String label, View.OnClickListener l) {
        Button b = new Button(this, null, android.R.attr.borderlessButtonStyle);
        b.setText(label);
        b.setAllCaps(false);
        b.setTextColor(Color.WHITE);
        b.setMinWidth(0);
        b.setMinimumWidth(0);
        b.setPadding(dp(12), 0, dp(12), 0);
        b.setOnClickListener(l);
        return b;
    }

    private void buildUi() {
        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setFitsSystemWindows(true);

        LinearLayout bar = new LinearLayout(this);
        bar.setBackgroundColor(NAVY);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        title = text(20, Color.WHITE);
        title.setTypeface(Typeface.DEFAULT_BOLD);
        title.setPadding(dp(16), 0, 0, 0);
        bar.addView(title, new LinearLayout.LayoutParams(0, dp(56), 1));
        title.setGravity(Gravity.CENTER_VERTICAL);
        bar.addView(button("+ New", v -> newMenu()));
        bar.addView(button("Menu", v -> mainMenu()));
        page.addView(bar);

        path = text(13, 0xFF555F73);
        path.setSingleLine(true);
        path.setEllipsize(TextUtils.TruncateAt.START);
        path.setPadding(dp(16), dp(10), dp(16), dp(10));
        path.setBackgroundColor(0xFFF1F3F7);
        path.setOnClickListener(v -> { if (!current.equals(root)) go(current.getParentFile()); });
        page.addView(path);

        FrameLayout middle = new FrameLayout(this);
        list = new ListView(this);
        list.setFastScrollEnabled(true);
        adapter = new Rows();
        list.setAdapter(adapter);
        list.setOnItemClickListener((a, v, pos, id) -> {
            Item it = items.get(pos);
            if (!selected.isEmpty()) toggle(it.file);
            else if (it.dir) go(it.file);
            else openFile(it.file);
        });
        list.setOnItemLongClickListener((a, v, pos, id) -> { toggle(items.get(pos).file); return true; });
        middle.addView(list);
        empty = text(16, 0xFF8A93A5);
        empty.setGravity(Gravity.CENTER);
        middle.addView(empty);
        page.addView(middle, new LinearLayout.LayoutParams(-1, 0, 1));

        bottom = new LinearLayout(this);
        bottom.setBackgroundColor(NAVY);
        bottom.setGravity(Gravity.CENTER);
        page.addView(bottom);
        setContentView(page);
        redraw();
    }

    private void addBottom(String label, View.OnClickListener l) {
        bottom.addView(button(label, l), new LinearLayout.LayoutParams(0, dp(56), 1));
    }

    private void redraw() {
        title.setText(selected.isEmpty() ? "Xtracta" : selected.size() + " selected");
        path.setText((current.equals(root) ? "" : "←  ") + current.getAbsolutePath());
        bottom.removeAllViews();
        if (!selected.isEmpty()) {
            addBottom("Compress", v -> compressDialog());
            addBottom("Copy", v -> clip(false));
            addBottom("Move", v -> clip(true));
            addBottom("Delete", v -> confirmDelete());
            addBottom("More", v -> moreMenu());
        } else if (!clipboard.isEmpty()) {
            addBottom((moving ? "Move " : "Paste ") + clipboard.size() + " here", v -> paste());
            addBottom("Cancel", v -> { clipboard.clear(); redraw(); });
        }
        bottom.setVisibility(bottom.getChildCount() == 0 ? View.GONE : View.VISIBLE);
        adapter.notifyDataSetChanged();
    }

    private final class Rows extends BaseAdapter {
        public int getCount() { return items.size(); }
        public Object getItem(int i) { return items.get(i); }
        public long getItemId(int i) { return i; }

        public View getView(int pos, View v, ViewGroup parent) {
            TextView[] h;
            if (v == null) {
                LinearLayout row = new LinearLayout(MainActivity.this);
                row.setGravity(Gravity.CENTER_VERTICAL);
                row.setPadding(dp(14), dp(10), dp(14), dp(10));
                TextView badge = text(11, Color.WHITE);
                badge.setGravity(Gravity.CENTER);
                badge.setTypeface(Typeface.DEFAULT_BOLD);
                badge.setBackground(new GradientDrawable());
                row.addView(badge, new LinearLayout.LayoutParams(dp(42), dp(42)));
                LinearLayout col = new LinearLayout(MainActivity.this);
                col.setOrientation(LinearLayout.VERTICAL);
                col.setPadding(dp(14), 0, 0, 0);
                TextView name = text(16, 0xFF171C28), info = text(12, 0xFF6B7486);
                name.setSingleLine(true);
                name.setEllipsize(TextUtils.TruncateAt.MIDDLE);
                col.addView(name);
                col.addView(info);
                row.addView(col, new LinearLayout.LayoutParams(0, -2, 1));
                v = row;
                v.setTag(h = new TextView[]{badge, name, info});
            } else h = (TextView[]) v.getTag();
            Item it = items.get(pos);
            String label; int color;
            if (selected.contains(it.file)) { label = "✓"; color = ORANGE; }
            else if (it.dir) { label = "DIR"; color = NAVY; }
            else if (Installer.isInstallable(it.name)) { label = "APK"; color = 0xFF2B8A3E; }
            else if (Archives.isArchive(it.name)) { label = "ZIP"; color = ORANGE; }
            else { label = "FILE"; color = 0xFF8A93A5; }
            h[0].setText(label);
            GradientDrawable g = (GradientDrawable) h[0].getBackground();
            g.setColor(color);
            g.setCornerRadius(dp(10));
            h[1].setText(it.name);
            h[2].setText(it.info);
            v.setBackgroundColor(selected.contains(it.file) ? SELECTED : Color.TRANSPARENT);
            return v;
        }
    }

    /* ---------- navigation ---------- */

    private void go(File dir) {
        current = dir;
        selected.clear();
        items.clear();
        redraw();
        list.setSelection(0);
        refresh();
    }

    /** Reads the folder off the UI thread so big folders never freeze the screen. */
    private void refresh() {
        final File dir = current;
        final int request = ++listing, order = sort;
        final boolean hidden = showHidden;
        empty.setText(items.isEmpty() ? "Loading…" : "");
        lister.execute(() -> {
            File[] files = dir.listFiles();
            List<Item> out = new ArrayList<>();
            Map<Item, long[]> keys = new HashMap<>();
            if (files != null) for (File f : files) {
                if (!hidden && f.getName().startsWith(".")) continue;
                Item it = new Item();
                it.file = f; it.name = f.getName(); it.dir = f.isDirectory();
                long time = f.lastModified(), size = it.dir ? 0 : f.length();
                it.info = (it.dir ? "Folder" : Formatter.formatShortFileSize(this, size))
                        + "  ·  " + DateFormat.format("dd MMM yyyy", time);
                keys.put(it, new long[]{time, size});
                out.add(it);
            }
            out.sort((a, b) -> {
                if (a.dir != b.dir) return a.dir ? -1 : 1;
                int c = order == 0 ? 0 : Long.compare(keys.get(b)[order - 1], keys.get(a)[order - 1]);
                return c != 0 ? c : a.name.compareToIgnoreCase(b.name);
            });
            ui.post(() -> {
                if (request != listing) return;
                items.clear();
                items.addAll(out);
                selected.removeIf(f -> !f.exists());
                empty.setText(files == null ? (hasAccess() ? "This folder can't be opened" : "File access is off.\nTap Menu → Allow access")
                        : out.isEmpty() ? "Empty folder" : "");
                redraw();
            });
        });
    }

    private void toggle(File f) {
        if (!selected.remove(f)) selected.add(f);
        redraw();
    }

    /* ---------- menus ---------- */

    private void choose(String heading, String[] options, Runnable... actions) {
        new AlertDialog.Builder(this).setTitle(heading).setItems(options, (d, i) -> actions[i].run()).show();
    }

    private void newMenu() {
        choose("Create", new String[]{"New folder", "New empty file"},
                () -> ask("New folder", "", n -> create(n, true)),
                () -> ask("New file", "", n -> create(n, false)));
    }

    private void mainMenu() {
        choose("Menu", new String[]{"Select all", showHidden ? "Hide hidden files" : "Show hidden files",
                        "Sort by name", "Sort by newest", "Sort by largest", "Go to storage root", "Allow access"},
                () -> { for (Item i : items) selected.add(i.file); redraw(); },
                () -> { showHidden = !showHidden; selected.clear(); refresh(); },
                () -> { sort = 0; refresh(); },
                () -> { sort = 1; refresh(); },
                () -> { sort = 2; refresh(); },
                () -> go(root),
                () -> { if (hasAccess()) toast("Access already allowed"); else askAccess(); });
    }

    private void moreMenu() {
        final File one = selected.iterator().next();
        final List<File> archives = new ArrayList<>();
        for (File f : selected) if (f.isFile() && Archives.isArchive(f.getName())) archives.add(f);
        List<String> names = new ArrayList<>();
        List<Runnable> actions = new ArrayList<>();
        if (selected.size() == 1) {
            names.add("Rename");
            actions.add(() -> ask("Rename", one.getName(), n -> rename(one, n)));
        }
        if (!archives.isEmpty()) {
            names.add("Extract each to its own folder");
            actions.add(() -> extract(archives, false, null));
        }
        names.add("Clear selection");
        actions.add(() -> { selected.clear(); redraw(); });
        choose("More", names.toArray(new String[0]), actions.toArray(new Runnable[0]));
    }

    private void openFile(File f) {
        String n = f.getName();
        if (Installer.isInstallable(n)) {
            choose(n, new String[]{"Install", "Extract contents"},
                    () -> install(f), () -> extract(Collections.singletonList(f), false, null));
        } else if (Archives.isArchive(n)) {
            choose(n, new String[]{"Extract to \"" + Archives.baseName(n) + "\"", "Extract here", "Extract with password"},
                    () -> extract(Collections.singletonList(f), false, null),
                    () -> extract(Collections.singletonList(f), true, null),
                    () -> askPassword(pw -> extract(Collections.singletonList(f), false, pw)));
        } else {
            Intent i = new Intent(Intent.ACTION_VIEW)
                    .setDataAndType(ShareProvider.uri(f), ShareProvider.mime(n))
                    .addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            try { startActivity(i); }
            catch (Exception e) { toast("No app can open this file"); }
        }
    }

    /* ---------- actions ---------- */

    private void create(String name, boolean folder) {
        File f = new File(current, name);
        try {
            if (f.exists()) toast("That name already exists");
            else if (folder ? !f.mkdir() : !f.createNewFile()) toast("Could not create it here");
        } catch (IOException e) { toast("Could not create it: " + e.getMessage()); }
        refresh();
    }

    private void rename(File f, String name) {
        File to = new File(f.getParentFile(), name);
        // A case-only change looks like "exists" on shared storage, so allow it.
        if (to.exists() && !name.equalsIgnoreCase(f.getName())) toast("That name already exists");
        else if (!f.renameTo(to)) toast("Rename failed");
        selected.clear();
        refresh();
    }

    private void clip(boolean move) {
        clipboard.clear();
        clipboard.addAll(selected);
        moving = move;
        selected.clear();
        redraw();
        toast("Open the target folder, then tap " + (move ? "Move here" : "Paste here"));
    }

    private void paste() {
        final List<File> src = new ArrayList<>(clipboard);
        final File dest = current;
        final boolean move = moving;
        run(move ? "Moving" : "Copying", "Done", p -> {
            for (File f : src) Ops.paste(f, dest, move, p);
        }, () -> clipboard.clear());
    }

    private void confirmDelete() {
        final List<File> victims = new ArrayList<>(selected);
        new AlertDialog.Builder(this).setTitle("Delete " + victims.size() + " item(s)?")
                .setMessage("This is permanent. There is no recycle bin.")
                .setPositiveButton("Delete", (d, w) -> run("Deleting", "Deleted", p -> {
                    for (File f : victims) Ops.delete(f, p);
                }, null))
                .setNegativeButton("Cancel", null).show();
    }

    private void compressDialog() {
        final List<File> src = new ArrayList<>(selected);
        final File dir = current;
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(20), dp(8), dp(20), 0);
        EditText name = new EditText(this);
        name.setSingleLine(true);
        name.setText(src.size() == 1 ? src.get(0).getName() : "Archive");
        name.selectAll();
        box.addView(name);
        Spinner format = new Spinner(this);
        format.setAdapter(new ArrayAdapter<>(this, android.R.layout.simple_spinner_dropdown_item, Archives.CREATE));
        box.addView(format);
        new AlertDialog.Builder(this).setTitle("Compress").setView(box)
                .setPositiveButton("Compress", (d, w) -> {
                    String f = (String) format.getSelectedItem(), n = name.getText().toString().trim();
                    if (!Ops.validName(n)) { toast("Invalid name"); return; }
                    File out = Ops.unique(new File(dir, n + "." + f));
                    run("Compressing", "Created " + out.getName(), p -> Archives.compress(src, out, f, p), null);
                }).setNegativeButton("Cancel", null).show();
    }

    private void extract(List<File> archives, boolean here, char[] password) {
        final List<File> src = new ArrayList<>(archives);
        run("Extracting", "Extracted", p -> {
            for (File f : src) {
                File parent = f.getParentFile();
                File out = here ? parent : Ops.unique(new File(parent, Archives.baseName(f.getName())));
                try {
                    Archives.extract(f, out, password, p);
                } catch (Exception e) {
                    if (!here) out.delete(); // removes it only if nothing was extracted
                    throw e;
                }
            }
        }, null);
    }

    private void install(File f) {
        if (!getPackageManager().canRequestPackageInstalls()) {
            toast("Allow Xtracta to install apps, then tap the APK again");
            startActivity(new Intent(Settings.ACTION_MANAGE_UNKNOWN_APP_SOURCES,
                    Uri.parse("package:" + getPackageName())));
            return;
        }
        run("Preparing install", null, p -> Installer.install(this, f, p), null);
    }

    @Override protected void onNewIntent(Intent i) { super.onNewIntent(i); handleInstall(i); }

    @SuppressWarnings("deprecation")
    private void handleInstall(Intent i) {
        // The token rejects fake status messages sent by other apps.
        if (i == null || !Installer.ACTION.equals(i.getAction())
                || !Installer.TOKEN.equals(i.getStringExtra("token"))) return;
        int status = i.getIntExtra(PackageInstaller.EXTRA_STATUS, PackageInstaller.STATUS_FAILURE);
        if (status == PackageInstaller.STATUS_PENDING_USER_ACTION) {
            Intent confirm = i.getParcelableExtra(Intent.EXTRA_INTENT);
            if (confirm != null) startActivity(confirm);
        } else if (status == PackageInstaller.STATUS_SUCCESS) {
            toast("App installed");
        } else if (status != PackageInstaller.STATUS_FAILURE_ABORTED) {
            message("Install failed", i.getStringExtra(PackageInstaller.EXTRA_STATUS_MESSAGE));
        }
        setIntent(new Intent());
    }

    /** Runs a long job in the background with a progress box and a Cancel button. */
    private void run(String heading, String success, Job job, Runnable onSuccess) {
        if (busy) return;
        busy = true;
        selected.clear();
        redraw();
        final java.util.concurrent.atomic.AtomicBoolean stop = new java.util.concurrent.atomic.AtomicBoolean();
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(24), dp(12), dp(24), 0);
        box.addView(new ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal) {{ setIndeterminate(true); }});
        TextView now = text(13, 0xFF555F73);
        now.setSingleLine(true);
        now.setEllipsize(TextUtils.TruncateAt.MIDDLE);
        box.addView(now);
        AlertDialog dialog = new AlertDialog.Builder(this).setTitle(heading).setView(box)
                .setCancelable(false).setNegativeButton("Cancel", (d, w) -> stop.set(true)).show();
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        Ops.Progress progress = new Ops.Progress() {
            long last;
            public void file(String name) {
                long t = SystemClock.uptimeMillis();
                if (t - last < 100) return; // throttle screen updates for speed
                last = t;
                ui.post(() -> now.setText(name));
            }
            public boolean cancelled() { return stop.get(); }
        };
        worker.execute(() -> {
            String error = null;
            try { job.run(progress); }
            catch (OutOfMemoryError e) { error = "Not enough memory. Try ZIP format."; }
            catch (Exception e) { error = e.getMessage() != null ? e.getMessage() : e.toString(); }
            final String result = error;
            ui.post(() -> {
                busy = false;
                if (isDestroyed()) return;
                dialog.dismiss();
                getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
                if (result == null) {
                    if (onSuccess != null) onSuccess.run();
                    if (success != null) toast(success);
                } else if (stop.get()) toast("Cancelled");
                else message(heading + " failed", result);
                refresh();
            });
        });
    }

    /* ---------- small dialogs ---------- */

    private interface Text { void accept(String s); }
    private interface Password { void accept(char[] s); }

    private void ask(String heading, String initial, Text done) {
        EditText e = new EditText(this);
        e.setSingleLine(true);
        e.setText(initial);
        e.selectAll();
        new AlertDialog.Builder(this).setTitle(heading).setView(e)
                .setPositiveButton("OK", (d, w) -> {
                    String s = e.getText().toString().trim();
                    if (Ops.validName(s)) done.accept(s); else toast("Invalid name");
                }).setNegativeButton("Cancel", null).show();
    }

    private void askPassword(Password done) {
        EditText e = new EditText(this);
        e.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_PASSWORD);
        new AlertDialog.Builder(this).setTitle("Password (7z and RAR)").setView(e)
                .setPositiveButton("Extract", (d, w) -> done.accept(e.getText().toString().toCharArray()))
                .setNegativeButton("Cancel", null).show();
    }

    private void message(String heading, String body) {
        new AlertDialog.Builder(this).setTitle(heading).setMessage(body).setPositiveButton("OK", null).show();
    }

    private void toast(String s) { Toast.makeText(this, s, Toast.LENGTH_SHORT).show(); }
}
