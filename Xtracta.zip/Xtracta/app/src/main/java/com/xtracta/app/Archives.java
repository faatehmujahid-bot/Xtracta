package com.xtracta.app;

import com.github.junrar.Archive;
import com.github.junrar.rarfile.FileHeader;
import org.apache.commons.compress.archivers.ArchiveEntry;
import org.apache.commons.compress.archivers.ArchiveInputStream;
import org.apache.commons.compress.archivers.ArchiveOutputStream;
import org.apache.commons.compress.archivers.sevenz.*;
import org.apache.commons.compress.archivers.tar.*;
import org.apache.commons.compress.archivers.zip.*;
import org.apache.commons.compress.compressors.bzip2.*;
import org.apache.commons.compress.compressors.gzip.*;
import org.apache.commons.compress.compressors.xz.*;

import java.io.*;
import java.util.*;

/** Compress and extract. No Android imports. */
public final class Archives {
    public static final String[] CREATE = {"zip", "7z", "tar", "tar.gz", "tar.bz2", "tar.xz"};
    private static final String[] READ = {".zip", ".jar", ".7z", ".rar", ".tar", ".tar.gz", ".tgz",
            ".tar.bz2", ".tbz2", ".tar.xz", ".txz", ".gz", ".bz2", ".xz", ".apks", ".xapk", ".apkm"};

    public static boolean isArchive(String name) {
        String n = name.toLowerCase(Locale.ROOT);
        for (String e : READ) if (n.endsWith(e)) return true;
        return false;
    }

    public static String baseName(String name) {
        String n = name.toLowerCase(Locale.ROOT), best = "";
        for (String e : READ) if (n.endsWith(e) && e.length() > best.length()) best = e;
        if (best.isEmpty()) { int d = name.lastIndexOf('.'); return d > 0 ? name.substring(0, d) : name; }
        String base = name.substring(0, name.length() - best.length());
        return Ops.validName(base) ? base : "extracted";
    }

    /* ---------- compress ---------- */

    public static void compress(List<File> sources, File out, String format, Ops.Progress p) throws IOException {
        if (out.exists()) throw new IOException(out.getName() + " already exists");
        boolean done = false;
        try {
            if (format.equals("7z")) {
                try (SevenZOutputFile z = new SevenZOutputFile(out)) {
                    for (File f : sources) add7z(z, f, f.getName(), out, p);
                }
            } else {
                try (ArchiveOutputStream a = open(out, format)) {
                    for (File f : sources) add(a, f, f.getName(), out, p);
                    a.finish();
                }
            }
            done = true;
        } finally {
            if (!done) out.delete();
        }
    }

    private static ArchiveOutputStream open(File out, String format) throws IOException {
        if (format.equals("zip")) {
            ZipArchiveOutputStream z = new ZipArchiveOutputStream(out);
            z.setLevel(5); // good balance of speed and size
            return z;
        }
        if (!Arrays.asList(CREATE).contains(format)) throw new IOException("Unknown format " + format);
        OutputStream raw = new BufferedOutputStream(new FileOutputStream(out), Ops.BUF);
        OutputStream s = raw;
        if (format.equals("tar.gz")) s = new GzipCompressorOutputStream(raw);
        else if (format.equals("tar.bz2")) s = new BZip2CompressorOutputStream(raw);
        else if (format.equals("tar.xz")) s = new XZCompressorOutputStream(raw);
        TarArchiveOutputStream t = new TarArchiveOutputStream(s, "UTF-8");
        t.setLongFileMode(TarArchiveOutputStream.LONGFILE_POSIX);
        t.setBigNumberMode(TarArchiveOutputStream.BIGNUMBER_POSIX);
        return t;
    }

    private static boolean skip(File f, File out) throws IOException {
        return (Ops.isLink(f) && f.isDirectory()) || f.getCanonicalFile().equals(out.getCanonicalFile());
    }

    private static File[] children(File dir) throws IOException {
        File[] k = dir.listFiles();
        if (k == null) throw new IOException("Cannot read " + dir.getName());
        return k;
    }

    private static void add(ArchiveOutputStream a, File f, String name, File out, Ops.Progress p) throws IOException {
        Ops.check(p);
        if (skip(f, out)) return;
        boolean dir = f.isDirectory();
        a.putArchiveEntry(a.createArchiveEntry(f, dir ? name + "/" : name));
        if (!dir) {
            p.file(name);
            try (InputStream in = new FileInputStream(f)) { Ops.pump(in, a, p); }
        }
        a.closeArchiveEntry();
        if (dir) for (File k : children(f)) add(a, k, name + "/" + k.getName(), out, p);
    }

    private static void add7z(SevenZOutputFile z, File f, String name, File out, Ops.Progress p) throws IOException {
        Ops.check(p);
        if (skip(f, out)) return;
        boolean dir = f.isDirectory();
        z.putArchiveEntry(z.createArchiveEntry(f, name));
        if (!dir) {
            p.file(name);
            byte[] b = new byte[Ops.BUF];
            try (InputStream in = new FileInputStream(f)) {
                int n;
                while ((n = in.read(b)) != -1) { Ops.check(p); z.write(b, 0, n); }
            }
        }
        z.closeArchiveEntry();
        if (dir) for (File k : children(f)) add7z(z, k, name + "/" + k.getName(), out, p);
    }

    /* ---------- extract ---------- */

    /** Extracts into dir (created if needed). Existing files are kept; new ones get a numbered name. */
    public static void extract(File src, File dir, char[] password, Ops.Progress p) throws IOException {
        if (!dir.isDirectory() && !dir.mkdirs()) throw new IOException("Cannot create " + dir.getName());
        String n = src.getName().toLowerCase(Locale.ROOT);
        if (n.endsWith(".zip") || n.endsWith(".jar") || n.endsWith(".apk") || n.endsWith(".apks")
                || n.endsWith(".xapk") || n.endsWith(".apkm")) unzip(src, dir, p);
        else if (n.endsWith(".7z")) un7z(src, dir, password, p);
        else if (n.endsWith(".rar")) unrar(src, dir, password, p);
        else if (n.endsWith(".tar")) untar(raw(src), dir, p);
        else if (n.endsWith(".tar.gz") || n.endsWith(".tgz")) untar(new GzipCompressorInputStream(raw(src), true), dir, p);
        else if (n.endsWith(".tar.bz2") || n.endsWith(".tbz2")) untar(new BZip2CompressorInputStream(raw(src), true), dir, p);
        else if (n.endsWith(".tar.xz") || n.endsWith(".txz")) untar(new XZCompressorInputStream(raw(src), true), dir, p);
        else if (n.endsWith(".gz")) single(new GzipCompressorInputStream(raw(src), true), src, dir, p);
        else if (n.endsWith(".bz2")) single(new BZip2CompressorInputStream(raw(src), true), src, dir, p);
        else if (n.endsWith(".xz")) single(new XZCompressorInputStream(raw(src), true), src, dir, p);
        else throw new IOException("Unsupported archive type");
    }

    private static InputStream raw(File f) throws IOException {
        return new BufferedInputStream(new FileInputStream(f), Ops.BUF);
    }

    /** Resolves an entry name inside root, rejecting "../" path traversal. */
    private static File target(File root, String entry) throws IOException {
        String clean = entry.replace('\\', '/');
        File f = root;
        for (String part : clean.split("/")) {
            if (part.isEmpty() || part.equals(".")) continue;
            if (part.equals("..")) throw new IOException("Blocked unsafe path in archive: " + entry);
            f = new File(f, part);
        }
        if (!Ops.inside(f, root)) throw new IOException("Blocked unsafe path in archive: " + entry);
        return f;
    }

    private static void mkdirs(File d) throws IOException {
        if (!d.isDirectory() && !d.mkdirs()) throw new IOException("Cannot create folder " + d.getName());
    }

    private interface Body { void writeTo(OutputStream out) throws IOException; }

    private static void write(File root, String name, boolean isDir, long time, Ops.Progress p, Body body) throws IOException {
        Ops.check(p);
        File f = target(root, name);
        if (f.equals(root)) return;
        if (isDir) { mkdirs(f); return; }
        mkdirs(f.getParentFile());
        f = Ops.unique(f);
        p.file(f.getName());
        boolean done = false;
        try (OutputStream out = new FileOutputStream(f)) {
            body.writeTo(out);
            done = true;
        } finally {
            if (!done) f.delete();
        }
        if (time > 0) f.setLastModified(time);
    }

    private static void unzip(File src, File dir, Ops.Progress p) throws IOException {
        try (ZipFile z = new ZipFile(src)) {
            for (ZipArchiveEntry e : Collections.list(z.getEntries())) {
                if (e.isUnixSymlink()) continue;
                if (e.getGeneralPurposeBit().usesEncryption())
                    throw new IOException("Password-protected ZIP files are not supported yet");
                if (!e.isDirectory() && !z.canReadEntryData(e))
                    throw new IOException("Unsupported ZIP compression method");
                write(dir, e.getName(), e.isDirectory(), e.getTime(), p, out -> {
                    try (InputStream in = z.getInputStream(e)) { Ops.pump(in, out, p); }
                });
            }
        }
    }

    private static void untar(InputStream in, File dir, Ops.Progress p) throws IOException {
        try (TarArchiveInputStream t = new TarArchiveInputStream(in, "UTF-8")) {
            TarArchiveEntry e;
            while ((e = t.getNextTarEntry()) != null) {
                if (!e.isDirectory() && !e.isFile()) continue; // links and devices
                if (e.isSymbolicLink() || e.isLink()) continue;
                if (!t.canReadEntryData(e)) throw new IOException("Unsupported TAR entry");
                write(dir, e.getName(), e.isDirectory(), e.getModTime().getTime(), p, out -> Ops.pump(t, out, p));
            }
        }
    }

    private static void single(InputStream in, File src, File dir, Ops.Progress p) throws IOException {
        try (InputStream s = in) {
            write(dir, baseName(src.getName()), false, 0, p, out -> Ops.pump(s, out, p));
        }
    }

    private static void un7z(File src, File dir, char[] pw, Ops.Progress p) throws IOException {
        try (SevenZFile z = new SevenZFile(src, pw)) {
            SevenZArchiveEntry e;
            while ((e = z.getNextEntry()) != null) {
                if (e.isAntiItem() || e.getName() == null) continue;
                long time = e.getHasLastModifiedDate() ? e.getLastModifiedDate().getTime() : 0;
                write(dir, e.getName(), e.isDirectory(), time, p, out -> {
                    byte[] b = new byte[Ops.BUF];
                    int n;
                    while ((n = z.read(b)) != -1) { Ops.check(p); out.write(b, 0, n); }
                });
            }
        }
    }

    private static void unrar(File src, File dir, char[] pw, Ops.Progress p) throws IOException {
        try (Archive a = new Archive(src, pw == null ? null : new String(pw))) {
            FileHeader h;
            while ((h = a.nextFileHeader()) != null) {
                final FileHeader entry = h;
                write(dir, h.getFileName(), h.isDirectory(), 0, p, out -> {
                    try { a.extractFile(entry, out); }
                    catch (Exception x) { throw new IOException("RAR extraction failed (wrong password or damaged file)", x); }
                });
            }
        } catch (IOException e) {
            throw e;
        } catch (Exception e) {
            throw new IOException("Cannot open RAR (RAR5 is not supported)", e);
        }
    }
}
