package com.xtracta.app;

import java.io.*;
import java.nio.file.Files;

/** File operations shared by the app. No Android imports, so it can be tested on a PC. */
public final class Ops {
    public interface Progress {
        void file(String name);
        boolean cancelled();
    }

    public static final class Cancelled extends IOException {
        Cancelled() { super("Cancelled"); }
    }

    static final int BUF = 256 * 1024;

    static void check(Progress p) throws Cancelled {
        if (p.cancelled()) throw new Cancelled();
    }

    static void pump(InputStream in, OutputStream out, Progress p) throws IOException {
        byte[] b = new byte[BUF];
        int n;
        while ((n = in.read(b)) != -1) {
            check(p);
            out.write(b, 0, n);
        }
    }

    static boolean isLink(File f) { return Files.isSymbolicLink(f.toPath()); }

    /** Returns f, or "name (1).ext" style if f already exists. Nothing is ever overwritten. */
    public static File unique(File f) {
        if (!f.exists() && !isLink(f)) return f;
        String n = f.getName(), ext = "";
        if (!f.isDirectory()) {
            int dot = n.toLowerCase().lastIndexOf(".tar.");
            if (dot <= 0) dot = n.lastIndexOf('.');
            if (dot > 0) { ext = n.substring(dot); n = n.substring(0, dot); }
        }
        for (int i = 1; ; i++) {
            File c = new File(f.getParentFile(), n + " (" + i + ")" + ext);
            if (!c.exists() && !isLink(c)) return c;
        }
    }

    public static boolean validName(String n) {
        return !n.isEmpty() && !n.equals(".") && !n.equals("..") && n.indexOf('/') < 0 && n.indexOf('\0') < 0;
    }

    public static void delete(File f, Progress p) throws IOException {
        check(p);
        if (f.isDirectory() && !isLink(f)) {
            File[] kids = f.listFiles();
            if (kids == null) throw new IOException("Cannot read " + f.getName());
            for (File k : kids) delete(k, p);
        }
        p.file(f.getName());
        if (!f.delete()) throw new IOException("Cannot delete " + f.getName());
    }

    static boolean inside(File child, File parent) throws IOException {
        String c = child.getCanonicalPath(), d = parent.getCanonicalPath();
        return c.equals(d) || c.startsWith(d + File.separator);
    }

    public static void paste(File src, File destDir, boolean move, Progress p) throws IOException {
        if (src.isDirectory() && inside(destDir, src))
            throw new IOException("Cannot put a folder inside itself");
        if (move && destDir.getCanonicalFile().equals(src.getCanonicalFile().getParentFile())) return;
        File dest = unique(new File(destDir, src.getName()));
        if (move && src.renameTo(dest)) return;
        try {
            copy(src, dest, p);
        } catch (IOException e) {
            try { delete(dest, QUIET); } catch (IOException ignored) { }
            throw e;
        }
        if (move) delete(src, p);
    }

    private static void copy(File src, File dest, Progress p) throws IOException {
        check(p);
        if (isLink(src)) throw new IOException("Links cannot be copied: " + src.getName());
        if (src.isDirectory()) {
            if (!dest.mkdir()) throw new IOException("Cannot create " + dest.getName());
            File[] kids = src.listFiles();
            if (kids == null) throw new IOException("Cannot read " + src.getName());
            for (File k : kids) copy(k, new File(dest, k.getName()), p);
        } else {
            p.file(src.getName());
            try (InputStream in = new FileInputStream(src); OutputStream out = new FileOutputStream(dest)) {
                pump(in, out, p);
            }
        }
    }

    static final Progress QUIET = new Progress() {
        public void file(String name) { }
        public boolean cancelled() { return false; }
    };
}
