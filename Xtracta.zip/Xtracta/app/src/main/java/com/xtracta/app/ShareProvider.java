package com.xtracta.app;

import android.content.ContentProvider;
import android.content.ContentValues;
import android.database.Cursor;
import android.database.MatrixCursor;
import android.net.Uri;
import android.os.ParcelFileDescriptor;
import android.provider.OpenableColumns;
import android.webkit.MimeTypeMap;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Locale;

/** Lets another app read one file the user chose to open. Not exported; access is granted per file. */
public class ShareProvider extends ContentProvider {
    static Uri uri(File f) {
        return new Uri.Builder().scheme("content").authority("com.xtracta.app.files")
                .appendPath(f.getAbsolutePath()).build();
    }

    static String mime(String name) {
        String ext = name.substring(name.lastIndexOf('.') + 1).toLowerCase(Locale.ROOT);
        String m = MimeTypeMap.getSingleton().getMimeTypeFromExtension(ext);
        return m != null ? m : "*/*";
    }

    private static File file(Uri u) { return new File(u.getLastPathSegment()); }

    @Override public boolean onCreate() { return true; }
    @Override public String getType(Uri u) { return mime(file(u).getName()); }

    @Override public ParcelFileDescriptor openFile(Uri u, String mode) throws FileNotFoundException {
        if (!"r".equals(mode)) throw new SecurityException("Read only");
        return ParcelFileDescriptor.open(file(u), ParcelFileDescriptor.MODE_READ_ONLY);
    }

    @Override public Cursor query(Uri u, String[] cols, String s, String[] a, String o) {
        if (cols == null) cols = new String[]{OpenableColumns.DISPLAY_NAME, OpenableColumns.SIZE};
        MatrixCursor c = new MatrixCursor(cols);
        Object[] row = new Object[cols.length];
        for (int i = 0; i < cols.length; i++) {
            if (OpenableColumns.DISPLAY_NAME.equals(cols[i])) row[i] = file(u).getName();
            else if (OpenableColumns.SIZE.equals(cols[i])) row[i] = file(u).length();
        }
        c.addRow(row);
        return c;
    }

    @Override public Uri insert(Uri u, ContentValues v) { return null; }
    @Override public int delete(Uri u, String s, String[] a) { return 0; }
    @Override public int update(Uri u, ContentValues v, String s, String[] a) { return 0; }
}
