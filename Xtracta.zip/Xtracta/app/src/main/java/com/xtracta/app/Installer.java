package com.xtracta.app;

import android.app.Activity;
import android.app.PendingIntent;
import android.content.Intent;
import android.content.pm.PackageInstaller;
import android.os.Build;

import java.io.*;
import java.util.*;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;

/** Installs APKs and split-APK bundles with Android's PackageInstaller. */
final class Installer {
    static final String ACTION = "com.xtracta.app.INSTALL_STATUS";
    static final String TOKEN = UUID.randomUUID().toString();

    static boolean isInstallable(String name) {
        String n = name.toLowerCase(Locale.ROOT);
        return n.endsWith(".apk") || n.endsWith(".apks") || n.endsWith(".xapk") || n.endsWith(".apkm");
    }

    static void install(Activity activity, File file, Ops.Progress p) throws IOException {
        PackageInstaller pi = activity.getPackageManager().getPackageInstaller();
        PackageInstaller.SessionParams params =
                new PackageInstaller.SessionParams(PackageInstaller.SessionParams.MODE_FULL_INSTALL);
        int id = pi.createSession(params);
        boolean committed = false;
        try (PackageInstaller.Session session = pi.openSession(id)) {
            if (file.getName().toLowerCase(Locale.ROOT).endsWith(".apk")) {
                try (InputStream in = new FileInputStream(file)) {
                    add(session, "base.apk", in, file.length(), p);
                }
            } else {
                addBundle(session, file, p);
            }
            Ops.check(p);
            Intent i = new Intent(activity, MainActivity.class).setAction(ACTION)
                    .addFlags(Intent.FLAG_ACTIVITY_SINGLE_TOP).putExtra("token", TOKEN);
            int flags = PendingIntent.FLAG_UPDATE_CURRENT;
            if (Build.VERSION.SDK_INT >= 31) flags |= PendingIntent.FLAG_MUTABLE;
            session.commit(PendingIntent.getActivity(activity, id, i, flags).getIntentSender());
            committed = true;
        } finally {
            if (!committed) {
                try { pi.abandonSession(id); } catch (Exception ignored) { }
            }
        }
    }

    private static void addBundle(PackageInstaller.Session s, File file, Ops.Progress p) throws IOException {
        String[] abis = {"arm64_v8a", "armeabi_v7a", "armeabi", "x86_64", "x86"};
        try (ZipFile z = new ZipFile(file)) {
            List<ZipEntry> apks = new ArrayList<>();
            for (ZipEntry e : Collections.list(z.entries())) {
                String n = e.getName().toLowerCase(Locale.ROOT);
                if (!n.endsWith(".apk") || n.startsWith("standalones/")) continue;
                apks.add(e);
            }
            if (apks.isEmpty()) throw new IOException("No APK files inside this bundle");
            // Pick the one processor split that best matches this phone.
            String wanted = null;
            for (String device : Build.SUPPORTED_ABIS) {
                String d = device.replace('-', '_');
                for (ZipEntry e : apks) if (abiOf(e.getName(), abis).equals(d)) { wanted = d; break; }
                if (wanted != null) break;
            }
            int index = 0;
            for (ZipEntry e : apks) {
                String abi = abiOf(e.getName(), abis);
                if (!abi.isEmpty() && !abi.equals(wanted)) continue;
                try (InputStream in = z.getInputStream(e)) {
                    add(s, "split" + (index++) + ".apk", in, e.getSize(), p);
                }
            }
        }
    }

    private static String abiOf(String entry, String[] abis) {
        String n = entry.toLowerCase(Locale.ROOT);
        for (String a : abis)
            if (n.endsWith("config." + a + ".apk") || n.endsWith("-" + a + ".apk")) return a;
        return "";
    }

    private static void add(PackageInstaller.Session s, String name, InputStream in, long size, Ops.Progress p)
            throws IOException {
        p.file(name);
        try (OutputStream out = s.openWrite(name, 0, size > 0 ? size : -1)) {
            Ops.pump(in, out, p);
            s.fsync(out);
        }
    }
}
