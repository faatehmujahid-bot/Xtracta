# Xtracta
Android file manager: install, extract, compress. Android 8.0 or newer.

## Get the APK (GitHub)
1. Create a new repository and upload everything inside this folder, including the hidden `.github` folder.
2. Open the Actions tab and wait for "Build Xtracta APK" to finish.
3. Download the `Xtracta-apk` artifact, unzip it and install `app-debug.apk`.

Or open the folder in Android Studio and press Run.

## Features
- Browse, new folder/file, rename, copy, move, delete, sort, hidden files
- Compress: zip, 7z, tar, tar.gz, tar.bz2, tar.xz
- Extract: zip, 7z, rar (RAR4 only), tar family, gz, bz2, xz (password: 7z and RAR)
- Install: apk, apks, apkm, xapk (OBB game data is not copied)

## Limits
- No password-protected ZIP, no RAR5, no creating password archives
- Keep the app open during long jobs
- `app/debug.keystore` is a test key; use your own private key for a store release
